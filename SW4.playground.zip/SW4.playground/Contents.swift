import SwiftUI

// Task 1
var numbers = Array(5...125)
numbers.removeFirst(5)
numbers[numbers.count - 5...numbers.count - 1] = [0, 0]
print(numbers)

// Task 2
var chess: [String: (alpha: Character, num: Int)?] = [
    "White King": ("E", 5),
    "White Queen": ("D", 4),
    "White Rook": ("H", 1)
]
chess["White Queen"] = nil

func checkFigure(f: String){
    if let coords = chess[f]{
        print("The \(f) is at (\(coords!.alpha), \(coords!.num))")
    } else {
        print("The \(f) has been killed.")
    }
}
checkFigure(f: "White King")
checkFigure(f: "White Queen")
