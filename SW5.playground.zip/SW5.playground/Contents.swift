// Task 1
func sumDouble(numArr numbers: [Double]) -> Double {
    var sum: Double = 0
    for n in numbers {
        sum += n
    }
    return sum
}
func sumDouble(numbers: Double...) -> Double {
    return sumDouble(numArr: numbers)
}
sumDouble(numbers: 2, 5, 12, 436.32, 1.2)

func avgDouble(numbers: Double...) -> Double {
    return sumDouble(numArr: numbers) / Double(numbers.count)
}
avgDouble(numbers: 2, 645, 1)

func invertSign(a: inout Int) { a = -a }
var i1 = 10
invertSign(a: &i1)

func doWithTwo(doFunc: (Double...) -> Double, d1: Double, d2: Double ) -> Double {
    return doFunc(d1, d2)
}
doWithTwo(doFunc: sumDouble, d1: 1.0, d2: 2.0)

func operation(which: String) -> (Double...) -> Double {
    switch which {
        case "sum":
            return sumDouble
        case "avg":
            return avgDouble
        default:
            return sumDouble
    }
}

func doOperation(operation: String) -> ((Double, Double) -> Double)? {
    switch operation {
        case "+":
            return {
                (a: Double, b: Double) in a + b
            }
        case "-":
            return {
                (a: Double, b: Double) in a - b
            }
        case "*":
            return {
                (a: Double, b: Double) in a * b
            }
        case "/":
            return {
                (a: Double, b: Double) in a / b
            }
        default:
            return nil
    }
}
let op: ((Double, Double) -> Double)? = doOperation(operation: "+")
if let result = op?(2, 3) {
    print("Result: \(result)")
}

// Task 2
let nums = [5, 2, 9, 1, 4, 6, 8, 7, 3]
let ascSorted = nums.sorted(by: {
    (a: Int, b: Int) -> Bool in
    return a < b
})
let descSorted = nums.sorted(by: {
    (a: Int, b: Int) -> Bool in
    return a > b
})

let bigNums: [Int?] = [23, 45, nil, 12, 34, 56, nil]
let numsSum = bigNums.map { (number) -> String in
    var sum = 0
    if let n = number {
        for s in String(n) {
            sum += Int(String(s))!
        }
        return String(sum)
    } else {
        return "nil"
    }
}
print(numsSum)

let arr2D = [[1,2,3],[34,56],[1,78,5]]
let convertTo1D = { (array: [[Int]]) -> [Int] in
    var result = [Int]()
    for subArray in array {
        for value in subArray {
            result.append(value)
        }
    }
    return result
}
let arr1D = convertTo1D(arr2D)

let vals = [10, 50, 100, 500]
let valsSum = vals.reduce(vals[0]) { (currentMax, value) in
    return max(currentMax, value)
}
