import UIKit

// Task 1
let a1 = "a1"
var a2 = 99
let i1: Int = 10
let d1: Double = 14.234375837463625
let s1: String = "hello"
let f1: Float = 13.524155
let b1: Bool = true
let s2: String = "STRING WITH NUM " + String(i1)
print(a1, a2, i1, d1, s1, f1, b1, s2)

let minValue = UInt8.min
let maxValue = UInt8.max
print(minValue, maxValue)

// Task 2
let fTwo = 0b101
let fTen = 5
let fSixteen = 0x5

let expo = 0.36e0

let number = 12305670.9805
let formattedNumber = String(format: "%.4f", number)

// Task 3
typealias Text = String

let c1: Text = "23523212"
let c2: Text = "253463246"
let c3: Text = "sdfsdg2342342"

if Int(c1) != nil { print(c1) }
if Int(c2) != nil { print(c1) }
if Int(c3) != nil { print(c1) }

var tup1 = (year: 2019, faculty: "FIT", num: 4)
print(tup1.0, tup1.1, tup1.2)
print(tup1.year, tup1.faculty, tup1.num)

tup1 = (2023, "F", 5)
let (con1, con2, con3) = tup1

var tup2 = (1000, "b", 13)
(tup1, tup2) = (tup2, tup1)
print(tup1, tup2)

// Task 4
var str1 = "142"
var str2: String?
let optType = Int(str1)

var i2: Int? = nil

// Task 5
let assumedString: String! = "Неявно развернутая опциональная строка"
print(assumedString)
if let definiteString = assumedString {
    print(definiteString)
}

// Task 6
let tup3 = (year: 1000, speciality: "prog", group: 7)

let defName = "noname"
var nilName: String?
var nameToUse = nilName ?? defName

// Task 7
let months = ["January", "Febrary", "December"]
let monthCount = months.count
for i in 0...2 {
    print(months[i])
}
for i in 0..<monthCount {
    print(months[i])
}

// Task 8
let name = "Anton"
let age = 19
let message = "My name is \(name) and I am \(age + 1) years old."

let blackHeart = "\u{2665}"

// Task 9
typealias Operation = (operandOne: Float, operandTwo: Float, operation: Character)
let oper: Operation = (3.1, 33, "+")
switch oper {
    case let (first, second, op) where op == "+":
        print(first + second)
    case let (first, second, op) where op == "*":
        print(first * second)
    case let (first, second, op) where op == "-":
        print(first - second)
    case let (first, second, op) where op == "/":
        print(first / second)
    default:
        print("No sich op")
}

// Task 10
let numbers = [2141, 64, 14, 123, 78, 2]
var summa = 0
for n in numbers {
    print(n)
}

var sum = 0
var i = 0
while i < numbers.count {
    sum += numbers[i]
    i += 1
}
print("Sum: \(sum)")

sum = 0
i = 0
repeat {
    sum += numbers[i]
    i += 1
} while i < numbers.count
print("Sum: \(sum)")

sum = 0
for i in stride(from: numbers.count - 1, through: 0, by: -1) {
    sum += numbers[i]
}
print("Sum: \(sum)")

for n in numbers {
    guard n != 14 else {
        break;
    }
    print(n)
}
